<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StatusSolicitacao extends Model
{
    
    protected $fillable     = ["id","status_solicitacao"];
}
