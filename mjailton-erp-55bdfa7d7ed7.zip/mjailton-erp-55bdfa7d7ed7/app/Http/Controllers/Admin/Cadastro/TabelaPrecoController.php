<?php

namespace App\Http\Controllers\Admin\Cadastro;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Acl\PermissaoTrait;
use App\Http\Requests\TabelaPrecoRequest;
use App\Models\TabelaPreco;

class TabelaPrecoController extends Controller
{
    use PermissaoTrait;
    public function __construct(){
        $this->modelName = 'tabelapreco';
    }
    
    public function index()
    {
        $this->checaPermissao(__FUNCTION__);
        $dados["lista"] = TabelaPreco::get();
        return view("Admin.Cadastro.TabelaPreco.Index", $dados);
    }
    
    public function create()
    {
        $this->checaPermissao(__FUNCTION__);
        return view("Admin.Cadastro.TabelaPreco.Create");
    }

    public function salvarJs(TabelaPrecoRequest $request){
        $req = $request->except(["_token","_method"]);
        TabelaPreco::Create($req);
        $lista = TabelaPreco::get();
        echo json_encode($lista);
    }
    
    public function listarTabelaPreco(){
        $lista = TabelaPreco::get();
        echo json_encode($lista);
    }
    
    public function store(TabelaPrecoRequest $request){
        $this->checaPermissao(__FUNCTION__);
        $req = $request->except(["_token","_method"]);
        $req["padrao"] = "N";
        TabelaPreco::Create($req);
        return redirect()->route('admin.tabelapreco.index')->with('msg_sucesso', "Inserido com sucesso.");
    }
   
    public function update(TabelaPrecoRequest $request, $id)
    {
        $this->checaPermissao(__FUNCTION__);
        $req     =   $request->except(["_token","_method"]);
        TabelaPreco::where("id", $id)->update($req);
        return redirect()->route("admin.tabelapreco.index")->with('msg_sucesso', "item alterado com sucesso.");;
    }
    
    public function edit($id){
        $dados["tabelapreco"]     = TabelaPreco::find($id);
        $dados["lista"]    = TabelaPreco::get();
        return view('Admin.Cadastro.TabelaPreco.Index', $dados);
    }
   
    

    public function pesquisa(){
        $q          = $_GET["q"];
        $lista      = TabelaPreco::where("nome","like","%$q%")->get();
        return response()->json($lista);
    }
    
   
    
    public function destroy($id)
    {
        $this->checaPermissao(__FUNCTION__);
        try{
            $h = TabelaPreco::find($id);
            if($h->padrao=="S"){
                throw new \Exception("Não é possível excluir o Tabela de Preço Padrão");
            }else{
                $h->delete();
            }
            return redirect()->back()->with('msg_sucesso', "item apagado com sucesso.");
        }catch (\Exception $e){
            $cod = $e->getCode();
            return redirect()->back()->with('msg_erro', "Houve um problema ao apagar [$cod]");
        }
    }
}
