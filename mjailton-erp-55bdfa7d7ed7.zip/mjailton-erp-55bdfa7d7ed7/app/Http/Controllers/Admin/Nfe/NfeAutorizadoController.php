<?php
namespace App\Http\Controllers\Admin\Nfe;

use App\Http\Controllers\Controller;

class NfeAutorizadoController extends Controller{ 
      
    
   
}
