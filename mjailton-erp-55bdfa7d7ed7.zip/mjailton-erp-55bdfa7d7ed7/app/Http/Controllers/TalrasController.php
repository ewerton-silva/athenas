<?php

namespace App\Http\Controllers;


class TalrasController extends Controller
{
    public function componentes(){
		return view('Admin.Talras.Componente');
	}
    public function novo(){
		//return view()
		
	}
	public function aqui(){
	    //
	}
}
